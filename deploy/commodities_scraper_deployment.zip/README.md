# Trading Economics Commodities Scraper

A Python application that scrapes and parses commodities data from tradingeconomics.com using an object-oriented architecture.

## Features

- **Class-based architecture** with clear separation of concerns
- Scrapes real-time commodities data including prices and performance metrics
- Parses multiple categories: Energy, Metals, Agriculture, Industrial, Livestock, etc.
- Exports data to CSV format
- Built-in data analysis and filtering capabilities

## Classes Overview

### 1. `Commodity` (dataclass)
Represents a single commodity with attributes:
- Name, Unit, Price, Change
- Daily %, Weekly %, Monthly %, Yearly %, 3-Year %
- Date

### 2. `WebScraper`
Handles HTTP requests and HTML retrieval
- `fetch_page()`: Downloads the webpage content

### 3. `TableParser`
Parses HTML tables and extracts commodity data
- `parse_tables()`: Extracts all commodities from the page
- `_parse_row()`: Converts table row to Commodity object

### 4. `CommodityDataManager`
Manages and analyzes commodity data
- `get_columns()`: Returns list of column names
- `display_summary()`: Shows data overview
- `display_data()`: Displays tabular data
- `filter_by_category()`: Filters by keyword
- `get_top_performers()`: Shows best/worst performers
- `export_to_csv()`: Exports to CSV file

### 5. `CommoditiesApp`
Main orchestrator class
- `run()`: Executes the complete scraping workflow

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python commodities_scraper.py
```

## Data Columns

The parsed table contains the following columns:
- **Name**: Commodity name
- **Unit**: Price unit (USD/Bbl, USD/t.oz, etc.)
- **Price**: Current price
- **Change**: Absolute price change
- **Daily %**: Daily percentage change
- **Weekly %**: Weekly percentage change
- **Monthly %**: Monthly percentage change
- **Yearly %**: Yearly percentage change
- **3-Year %**: 3-year percentage change
- **Date**: Last update date

## Example Output

```
================================================================================
COMMODITIES DATA SUMMARY
================================================================================
Total commodities: 100+

Columns: Name, Unit, Price, Change, Daily %, Weekly %, Monthly %, Yearly %, 3-Year %, Date
================================================================================
```

## License

MIT License
